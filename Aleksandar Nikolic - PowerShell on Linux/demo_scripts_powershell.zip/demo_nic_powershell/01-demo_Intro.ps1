<#
PowerShell Core on Ubuntu VM
PowerShell Core in WSL
PowerShell Core in Azure Cloud Shell

docker run -it --rm mcr.microsoft.com/powershell:6.1.2-ubuntu-18.04 pwsh
#>


